# Projeto Prático em C - Sistema de Cadastro de Produtos

## Integrantes

1. Nome do integrante 1
2. Nome do integrante 2
3. Nome do integrante 3
4. Nome do integrante 4
5. Nome do integrante 5
6. Nome do integrante 6

## Descrição

Sistema desenvolvido em linguagem C para cadastro e gerenciamento de produtos de uma loja.

O programa utiliza:

- `struct`
- funções
- menu de opções
- `switch`
- estruturas de repetição e condicionais
- arquivos texto/CSV
- `fopen()` e `fclose()`
- `fprintf()` e `fgets()`
- `strtok()`
- `strcpy()`
- `strcmp()`

## Funcionalidades

1. Cadastrar produto
2. Listar produtos
3. Buscar produto por nome
4. Buscar produtos por categoria
5. Buscar produtos por faixa de preços
6. Remover produto
7. Atualizar produto
0. Sair

## Estrutura do produto

Cada produto possui:

- Nome
- Categoria
- Preço

A estrutura utilizada no programa é:

```c
typedef struct {
    char nome[100];
    char categoria[50];
    float preco;
} Produto;
```

## Arquivo CSV

Os dados ficam armazenados no arquivo `produtos.csv`.

O separador utilizado é `;`.

Exemplo:

```text
Teclado;Perifericos;89.90
Mouse Gamer;Perifericos;149.90
Monitor;Eletronicos;899.00
```

Os dados permanecem salvos mesmo depois que o programa é encerrado.

## Validações

O programa verifica:

- opção inválida no menu;
- preço negativo;
- preço mínimo negativo;
- preço máximo negativo;
- preço mínimo maior que o máximo;
- nome e categoria vazios;
- tentativa de inserir `;` dentro dos campos;
- erros de abertura/criação dos arquivos.

## Como executar no Dev-C++

1. Abra o Dev-C++.
2. Crie um novo projeto ou arquivo fonte em C.
3. Salve o código como `produtos.c`.
4. Coloque `produtos.csv` na mesma pasta do arquivo executável/projeto.
5. Compile o programa.
6. Execute.

No Dev-C++, utilize:

**Executar > Compilar e Executar**

ou a tecla de atalho correspondente à versão instalada.

## Como funciona a remoção e atualização

Para remover ou atualizar um produto, o programa utiliza um arquivo temporário chamado `temp.csv`.

O programa lê os produtos do arquivo original. Na remoção, grava no arquivo temporário todos os produtos, exceto aquele que deve ser removido.

Na atualização, grava os demais produtos e substitui o registro encontrado pelos novos dados.

Depois, o arquivo original é substituído pelo arquivo temporário.

## Testes sugeridos para apresentação

### Cadastro

Cadastrar:

- Nome: Mouse Gamer
- Categoria: Perifericos
- Preço: 149.90

### Busca por nome

Pesquisar:

```text
Monitor
```

### Busca por categoria

Pesquisar:

```text
Perifericos
```

### Busca por faixa

Testar:

```text
Minimo: 50
Maximo: 200
```

### Opção inválida

Digite:

```text
9
```

O sistema deverá informar que a opção é inválida.

### Preço negativo

Tente cadastrar:

```text
-50
```

O sistema deverá impedir o cadastro.

## Apresentação

Durante a apresentação, demonstrar:

- cadastro;
- listagem;
- busca por nome;
- busca por categoria;
- busca por faixa de preços;
- remoção;
- atualização;
- validação de opção inválida;
- validação de preço negativo;
- conteúdo do arquivo `produtos.csv`.

## Observação

Antes da entrega, substituir os nomes dos integrantes acima pelos nomes reais do grupo e adicionar o link do vídeo de apresentação do YouTube.
